document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault();

    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;
    var password = document.getElementById('password').value;
    var message = document.getElementById('message').value;

    var errorMessages = '';

    if (name.trim() === '') {
        errorMessages += 'Por favor, preencha o campo de nome.<br>';
    }

    if (email.trim() === '') {
        errorMessages += 'Por favor, preencha o campo de email.<br>';
    } else if (!isValidEmail(email)) {
        errorMessages += 'Por favor, insira um email válido.<br>';
    }

    if (password.trim() === '') {
        errorMessages += 'Por favor, preencha o campo de senha.<br>';
    }

    if (message.trim() === '') {
        errorMessages += 'Por favor, preencha o campo de mensagem.<br>';
    }

    document.getElementById('error-messages').innerHTML = errorMessages;

    if (errorMessages === '') {
        alert('Formulário enviado com sucesso!');
        document.getElementById('contactForm').reset();
    }
});

function isValidEmail(email) {
    var re = /\S+@\S+\.\S+/;
    return re.test(email);
}
